Change Log
==========

Version 3.0.0 *(2017-01-10)*
----------------------------

 * Remove the compatibility to non-Android Java.
 * Use Android library Gradle plugin instead of Java plugin
 * Build-script generate AAR instead of JAR file.


Version 2.0.0 *(2016-04-26)*
----------------------------

 * Change Retrofit dependency from using beta2 to a stable release version 2.0.0.


Version 1.0.0 *(2016-01-29)*
----------------------------

Initial release.

